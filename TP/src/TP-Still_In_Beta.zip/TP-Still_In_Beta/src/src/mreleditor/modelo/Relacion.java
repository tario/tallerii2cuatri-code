/**
 * 
 */
package mreleditor.modelo;

import mereditor.modelo.base.Componente;

/**
 * @author guido
 *
 */
public class Relacion extends Componente{

}
