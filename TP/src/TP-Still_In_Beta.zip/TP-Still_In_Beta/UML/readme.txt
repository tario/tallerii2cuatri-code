La entrega contiene las siguientes carpetas:
	- docs
	- src

docs:
-----

Aqu� se encontrar�n los documentos de an�lisis, t�cnico y el manual del usuario, cada uno de ellos en formato PDF para que puedan ser visualizados en cualquier plataforma.

src:
----

Adem�s de contener el c�digo fuente de la aplicaci�n, el cual est� acompa�ado de un archivo de proyecto para eclipse, esta carpeta contiene dos jars ejecutables de Java.

 - mereditor-win32.jar 
	Para utilizar la aplicaci�n en una plataforma Windows de 32 bits.
 - mereditor-win64.jar
	Para utilizar la aplicaci�n en una plataforma Windows de 64 bits.

Requerimientos del sistema:
---------------------------

El sistema donde se quiera correr la aplicaci�n MER-Editor debe tener por lo menos la versi�n 1.7 Java Runtime Environment.
 


